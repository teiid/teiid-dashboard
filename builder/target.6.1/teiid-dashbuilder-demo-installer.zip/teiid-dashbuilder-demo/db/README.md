This directory contains the demo application database, normally the following three files:
    dashbuilder.h2.db
    dashbuilder.trace.db
    dashbuilder.lock.db

If you delete these files the database will be regenerated next time you start the demo application.
